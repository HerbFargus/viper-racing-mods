69Day22.car  CONVERTED FROM Re-Volt TO VIPER RACING 14 Feb 2018 BY:

VAL IN MOOSE JAW , SASKATCHEWAN , CANADA.

One crash sound was modified 23 Feb 2018 ( just for fun ).

THIS CAR WAS SPECIALLY CONVERTED TO RACE DAYTON , BUT IT
 STILL  HANDLES OK ON ADD-ON TRACKS AND ALL OTHER ORIGINALS.

e-mail          val5662@yahoo.com

Thanks to the original author ->        Xarc
His Email Address in his original readme ->   warrockrockwar@hotmail.it


PERMISSION INFO:
 If you want to convert this car to any other game go ahead...
.......BUT if you want to modify this car and keep it in Viper 
Racing , go ahead but please rename the car files so we dont have 2 cars with the same name.
Also if you want to use parts from this car , go ahead.
After all , it's only a game.
Thanks!
Cya on the track.
                 Have a great day! 
 