AIcarman - the AI car management program for Viper Racing   Version 1.1

This is a new version working with the new patches 1.21 and 1.23 as well! All other things are unchanged!

This program was designed to let you easily change the car that the AI drivers (computer opponents, Finkel & Co.) use. You will not be able to select the ViperGT as AI car, this is done by an entry in the options.cfg file (change opponent_strength to 6).


What the programs does: 
it changes an entry in the race.bin, so you don#t have to mess with hex editors etc.

For a short overview of how to use look at the picture AIhelp.jpg, that came with this program.

How to install:

1) Move all files in the zip (except this readme and the AIhelp.jpg) to the Data folder inside the Viper game, normally C:\Sierra\Viper Racing\Data.

2) Make sure the car you want to select as AI car is activated, i.e. showing in options, hacks dialog in the game. If you can drive it, it is activated. You can use my program CarMan to easily manage your addon cars.

3) Now start AIcarman.exe by doubleclicking, and you see a listbox that left shows your activated cars (the ones that show in VR). Click on one of them, and the picture of this car is shown (if there is a picture in jpg-format with the same name in the same folder). The line under the title shows you which car is used by the AI drivers at the moment.

4) After having selected a car on the left, you can click "Apply", and this car becomes the AI car (see the text above the list and picture change!).

5) If you want to get back to the normal state, AI driving Viper, just click "Reset", and all is set back to default.

8) To manage your wheels in quite the same easy way, install WheelMan from my page.

Troubleshooting:

Q: The left listbox is empty.
A: You have started the program from a location, where no cars are stored. To work properly, the AIcarman.exe has to be in the Data folder of Viper, or it won't find nothing.

This program is freeware, use it at your own risk, there is no liability implied to any damages to your cars or Viper game or other things whatsoever.

Should anything go wrong, inspite all testing and care: the program makes a copy of the file race.bin, before it changes anything. It is called racebin.bak and can be found in the same folder. In case of trouble, just delete the race.bin, and rename racebin.bak back to race.bin. 

Developed by Frank P. Wolf for the worldwide Viper community to promote use and racing of as many new cars as you might wish.

For any questions or comments, good or bad, send me a mail FPWolf@aol.com, or visit my homepage http://members.aol.com/racingwolf999
You can also download CarMan, WheelMan and TrackMan there, as well as lots of cars, rims, pictures and new tracks to use with the best race sim ever.

Credits: Thanks to Ashes48, the hex hacker king, for finding it all out!

Happy Racing all, come to chat in Yahoo Viper Racing Club and let's burn some rubber! 