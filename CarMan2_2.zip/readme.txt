CarMan - the car management program for Viper Racing   Version 2.2

This new version is adapted to the change from maximum 13 to maximum 17 cars, as performed by the program MoreCars enclosed in the zip (see file morecars.txt). The only change to version 2.0 is that the red warning bar appears at more than 17 cars instead of more than 13 cars. All other functions are exactly the same.

Thanks go to Joe Forster (STA) and Brett for finding out the details about the cars window section in race.bin.

This program was designed, because Viper Racing (VR) can not show more than 17 cars maximum, when selecting a car in the hacks screen of the options section. So you have to limit the number of your active (selectable) cars to 17. All other cars have to be renamed or moved to a different folder, otherwise VR starts listing all .car-files in the Data folder following the alphabet, so that you will not be able to select e.g. the ViperGT.

What the programs does basically: 
it changes the extension of the cars that you don't want to use for the next race from .car to .cat, so they don't show up. You can easily activate or de-activate your cars in a normal graphical windows interface.

Installation: quite easy, unpack all files to your Data folder inside the Viper Racing folder, normally C:\Sierra\Viper Racing\Data. You don't have to keep this readme file, of course, and also, if you used an older version of CarMan before, you will already have the nosuch.jpg, no need to copy again, it's exactly the same.

The basic functionality is exactly the same as version 1.0, you activate or deactivate cars by selecting it in the appropriate list box and then click the button "activate" or "deactivate".

For those who love reading, here is a more detailed explanation:

LEFT LIST shows all the cars in your Data folder that are not activated at the moment, i.e. not available in the game's options, hacks screen.

RIGHT LIST on the other side shows all the cars in your Data folder that are activated at the moment, i.e. available in the game's options, hacks screen and used during game.

To make a car available in game, you just have to move it from the left to the right box. You can do so in several ways: 
a) click on the car to select it, then click on the 
   >>ACTIVATE>> button, and it will move over to the right.
b) doubleclick on the car, with same result.
c) press Alt-A, whoosh, over it moves!
d) use drag and drop like in Windows Explorer.

If you have more than 17 cars activated in the game, then a red vertical bar will show at the right list. This is to warn you, that you will not see all your cars in the hacks screen. No big deal, just deactivate one or more.

Deactivating is done like activating, but only from right to left:
a) click on the car to select it, then click on the 
   <<DEACTIVATE<< button, and it will move over to the left.
b) doubleclick on the car, with same result.
c) press Alt-D, whoosh, over it moves!
d) use drag and drop like in Windows Explorer.

To activate or deactivate more than one car, use multi-select just as in your Explorer. Pressing the Ctrl-key while clicking selects multiple cars not next to each other, pressing the Shift-key and clicking selects a block of cars adjacent to each other. Drag and drop works for these as well.

For those who don't love the mouse: you can also use the up/down arrow keys to select cars, and Ctrl works here too.

Whenever you select a car, be it on the left or right, a picture of the car is shown in the middle (as long as a picture in jpg-format is available), and the file name of that car is shown on the top of the picture.

Please note that with multi-select or clicking on the left or right alternately, always the last selected car is shown.

To get more information about the performance of that car, just click the picture. A message box opens, showing weight, horsepower and torque.

If you take part in racing series, which request loading the same set of cars every weekend etc., you can make use of the "Load a set" function.
Now what are sets? Sets are simple text files with the ending ".set", written with Notepad or any other plain text editor (don't use Word), naming one car per line. You can keep these set files in any location you want, the default though is the Data folder.

How do i load a set? Very simple, click on the "LOAD A SET"-button. A normal file opening dialog shows, navigate to the set you want to load, and click OK. Now the picture in the middle changes to a list, showing which cars are in this set. If this is the set you want. click "OK, LOAD!", otherwise click CANCEL.
CarMan checks if all cars in the set are present in your Data folder, and gives a warning if not.

You can easily create sets by activating the wanted cars, so they show in the right box, and then click "SAVE AS SET". A normal Save-Dialog appears, and you can chose the folder and name where to store this set list.

WARNING: when creating or loading sets, or activating/deactivating cars as mentioned above, always make sure that your activated cars include the regular Viper named viper.car. Viper Racing needs this car badly for career mode and a lot of other reasons, and the game will not run without it. When closing CarMan, it will give you a warning if no viper.car is activated. Don't neglect this warning!
For the same reason, also always include the viper.car in all your sets, cos CarMan completely flushes the right box before loading a set.

If you are using my programs WheelMan for selecting custom rims, and TrackMan for managing add.on tracks, 2 appropriate buttons will be visible on the lower edge, allowing you to easily start these programs from CarMan.

Forgot something? Ah yes, above the left and right list boxes you see the number of cars in the box thereunder.
What do you say? "I can read myself!" Oh, yes, that's why i stop chatting now.

Only two more things:

- If CarMan don't work correctly, the two most common reasons are your cars are write-protected or you have installed CarMan in the wrong folder. The Data folder within Sierra\Viper Racing is the right one, it won't work in unknown, far distant places...

- This game is freeware, use it at your own risk, there is no liability implied to any damages to your cars or Viper game or other things whatsoever.

Developed by Frank P. Wolf for the worldwide Viper community to promote use and racing of as many new cars as you might wish.

For any questions or comments, good or bad, send me a mail FPWolf@aol.com, or visit my homepage http://members.aol.com/racingwolf999
You can also download WheelMan there, as well as lots of rims and pictures to use with CarMan for all existing cars.

Happy Racing all, come to chat in Yahoo Viper Racing Club and let's burn some ruber! 

Thanks go to Ashes, Tony, Joe Forster(STA), Brett and the two Dave's, for all their help and input, and to all the MGI stuff for having written the most realistic car simulation in the world, still going strong after 6 years!

No user-serviceable parts inside. Handle with care, use no hooks, keep out of the reach of children, and don't expose to plain sunlight. If you don't like the red-on-aqua header of the program, get lost or wear sunglasses, LOL!