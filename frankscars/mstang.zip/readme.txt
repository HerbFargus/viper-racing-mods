To run: Extract mstang.car into Viper Racing/Data folder.

1969 Mustang Mach 1
-------------------
General Info:
428ci
400 HP
425 Torque
RWD
Wider rear wheels
Larger diameter rear wheels
Muscle car sounds
Damage: no
Cockpit: yes
Paintable: no
Custom Wheels: no

Requires 1.2.1 Patch to run!

Thanks to
---------
Frank (http://members.aol.com/racingwolf999 and racingwolf999@aol.com)
for making restools, the cockpit, setting the body in zmod, for helping me make the entire
thing! I would have gone nowhere without his help.

Robert Clark (Gundam0076@aol.com) for making the mesh for NFS4 (and letting me convert it)

Impreza WRX a.k.a. Supra_Twinturbo_R (http://supra_twinturbo_r.tripod.com/) for letting
me use the Cutlass as a base and help with sound effects.
---------------
Converted by Chris (zchris87v@yahoo.com and hometown.aol.com/zchris87v/vr)
By the way this is my first conversion.
