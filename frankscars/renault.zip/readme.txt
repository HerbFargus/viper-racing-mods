This is the reworked version of one of the first cars i converted from SCGT to Viper, the Renault Clio V6 in race version. The performance now is equivalent to the Xmas car (Viper GTR-S), and changed from front to rear drive. Put both renault.car and renault.jpg in your Sierra\Viper Racing\Data folder.
For easy car management, download my program CarMan from my site:
http://members.aol.com/racingwolf999
If you have any questions or remarks, please mail me:
FPWolf@aol.com
But please don't mail requests for new cars, they will have no chance to make it. The piles on my desk already are way too high, LOL!