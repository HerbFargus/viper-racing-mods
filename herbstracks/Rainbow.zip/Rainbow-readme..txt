Rainbow track Made for VIPER RACING made using Bob's Track Builder, 3dsMax, Zmodeler, and Sucahyo's vrTrackmaker July 26, 2020 BY:

Herb Fargus

Thanks to Val in Moosejaw for hosting all the tools and the online tutorials
and all the other previous coders who created the tools that make track making possible

PERMISSION INFO:
Use it however you will, I just made the track for fun.