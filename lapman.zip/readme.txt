LapMan vers. 1

Are you tired of being restricted to the same old numbers of laps for the 3 race 
lengths in Viper? Well, here's the solution.

This program allows you to set the number of laps for each of the three race 
lengths, short, medium and long, individually for each track.

The program is almost self-explanatory. You see the 8 tracks on the left, and three 
columns of sliders and input boxes, named short, medium and long. Slide the slider 
or type the number of laps in the appropriate box. Both depend on each other, and 
will change accordingly. While the input boxes allow to set lap numbers to as many as
99 laps (poohh!!!!!), the sliders only range from 1 to 30, the most used range, for 
precision reasons. You won't set zero laps, do you?

If you want to set the lengths for all tracks equally, click the lock checkbox below 
the column, and all sliders and figures will change together.

Don't forget to click "Apply" after you have done all settings!!!!!!!!!

After you have worked out a nice scheme, you maybe will not have to enter these values
again and again. Then just click "Save to file", LapMan will ask you for a location and 
a name and create an ini-file for you. Later you can always click "Load from file",
and load these values from the ini-file. And, you can have as many ini-files as you want.

The program also offers you a way to have a mirror in the near-chase-view (F5), see the 
lower part of the program window. To do so, just click "OK, set!". The only drawback is, 
you will lose the mirror in F3-view (where you see the shock absorbers). But you can always
return to default by clicking "Reset".

Installation: very easy, just unzip lapman.exe and findviper.exe to any folder you want, but make sure they both are in the same folder. 
At the first start, LapMan will start FindViper, a small program that scans your drives for Viper installations. It does so by searching all drives for the file race.bin. 
You then see the lower list box of FindViper filled with all locations where a race.bin was found. Select those folders that do not hold a complete Viper installation you use, one by one, and click Remove. This entry will then be removed from the list (NOT deleted on your drive of course!). 
After this you have a list of different versions you actually play. This is for those who use different installations for different clubs etc. Normal users of course will only have one installation.
Now click Save and Exit, and FindViper creates an ini-file in your Windows folder, saving the location(s) of the game. Do not delete this ini-file, it is needed so that you don't have to tell LapMan again and again where the game resides. Also, this ini-file will be used later by other programs, like new versions of TrackMan and CarMan.
LapMan and FindViper make no changes to your registry or system files. Never! Period!             
 
This program only works with the version 1.2.3 of Viper (and for the server version), you must have this patch installed.
It will do no harm to other versions, but just abort.

LapMan is to be used before you start the game, it can not change anything when Viper is running!

LapMan also caters for add-on tracks, it uses the short names of add-on tracks. So if you have, by example, loaded Assen on Bemidji, you will find Assen instead of Bemidji in the track list. But all changes you make to race length here, will be applied to Bemidji as well when you reset to it in TrackMan.

Credits: 
Big thanks goes to 
Joe Forster/STA     
who found out all the offsets for these changes, a perfect hacker :))

And of course big thanks too to Tony (xtonyx) for stimulating me to write these programs,
also he made the contact with Joe Forster. Thanks for all your never-ending input, dude!


No animals were used in making this program. No user-serviceable parts inside. Keep out of plain 
sunlight and the reach of children! Use no hooks!
Who the hell wrote "Broske sucks" in the race.bin?????????
  