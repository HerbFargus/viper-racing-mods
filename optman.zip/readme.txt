OptMan - the program to manage options in Viper Racing   Version 1.0

This program was designed to easily manage some of the settings that are stored in options.cfg, but can not be set within the game. 

What the programs does:
 
It processes the file options.cfg, which is a simple text file in your Sierra\Viper Racing\Config folder. Of course you can change these settings also in Notepad or any other text processor that saves plain text, but if you do some mistyping, maybe your game won't run anymore. OptMan avoids these troubles by offering a simple click and set Windows interface.

How to install:

1) Unpack the zip and move the file optman.exe into your Sierra\Viper Racing\Config folder (not in the Data folder like all my other Viper program!). That's all! Don't try to use OptMan from any other folder, it simply won't work. If you wish, you can make a shortcut to it on your desktop, so changing the settings is in easy reach.

What do the different points mean?

Well, let's look at the possible settings from top to bottom:

Time of day: by checking this box, the sky becomes black, and the surroundings also get a bit darker, so you have the impression of racing at night. Try it, it looks beautiful on some tracks!

Weather: this makes the road look wet, reflecting the car's underside much more. There is nothing big to it, just a funny little gimmick. Some say that they can feel a slight loss of grip, but it's hard to tell what is fact and what is imagination here. My lap times did not slow down in any way.

Opponent strength: this is one of the most important features, it makes the AI drivers (Finkel & Co.) drive the more powerful GTS-R car instead of the stock Viper. By checking this box xou get some more demanding sparring partners when tweaking your setups or practising offline.

Spotter: if you play with sound (who the hell don't?), you will hear a voice telling you where cars in your neighbourhood are, like: "Left", "Clear" etc. But the spotter is a very unsocial guy, don't expect a word of pity when you spin out, or some encouragement when you try hard to follow the car in front of you.

Number of AI opponents: in game this can only be set to up to 7, but Viper can handle 14 max. When Viper was launched back in 1998 (!), it required a high-end computer to run more than 7 cars at a decent frame rate, but with nowadays fast machines every up-to-date combination of cpu and 3d graphics adapter should easily be able to handle 14. But watch out: such a crowd of stupid AI drivers can pest your life and spoil your every lap, lol!

Fog: this makes the distance a bit more obscured, it is not much of an effect, but the difference can be seen. It does make no other changes, so just try out. It can slow down frame rates on slow machines though!

FOV: Field of view, this changes the distance to your car when driving in chase view, just try to find the most convenient setting. NOTE: this feature requires the original CD in the drive, so if you have lost the CD, be careful :))

Player's name: don't expect me to explain this!

Save and exit: clicking here writes the changes you made to the options.cfg, and you will see the change the next time you start your fav game.

Reset to default: this rebuiltds the original settings, i.e. daylight, dry, opponent strength hard but not using GTS-R (you can set to medium or easy in game, but come on...), 7 AI cars (also this can be reduced below 7 in game), spotter off and gives you the name "Player", like immediately after a new install.

Exit without saving: nice to have met you, but why do you use my program and make it do nothing?

Please note: all these settings only are valid in Quick Race mode, they don't affect the career mode, where Viper alone has total control over all.

Troubleshooting:

There are no troubles, so don't ask me to shoot them. Just to give you some peace of mind:
At the start, long before you see something, OptMan makes a copy of your options.cfg, called options.bak. Should ever go anything wrong, just delete options.cfg and rename options.bak to options.cfg. Just in case you start the program after a new install of Viper, without having played only once, there is only a options.def in your Config folder. In this case, OptMan makes a copy of options.def and calls it options.cfg, so we have something to play with.
Also at the start, faster than your eyes can watch, OptMan reads the actual setting from the options.cfg, so what you see at the start reflects the momentary settings. 

This game is freeware, use it at your own risk, there is no liability implied to any damages to your tracks or Viper game or other things whatsoever.

NOTICE: While all attention was taken to trap any user errors, try to avoid unsenseful or irritating usage. For example, if you run OptMan and Viper at the same time, and make changes vice versa once here and once there, or maybe even manually too in Notepad, you will get what you are apparently looking for: a mess!

Developed by Frank P. Wolf for the worldwide Viper community to promote use and racing of as many new tracks as you might wish.

For any questions or comments, good or bad, send me a mail FPWolf@aol.com, or visit my homepage http://members.aol.com/racingwolf999
There you will also find the other Viper assisting programs from me: CarMan to manage your addon cars, WheelMan to put new wheels on, TrackMan to integrate the new addon tracks, AIcarman to make the AI drive addon cars, and a lot more fine stuff!

Credits:

This program makes use of a Delphi routine called GetToken, written by Thomas Stutz (http://www.swissdelphicenter.ch), thanks a lot for this, it came just at the right moment!
Thanks fly to my friend Ashes48, who has found out most of the settings by simply changing anything he gets hold of, and seeing what happens.
Yes, and of course a very big Thank You to all the staff at MGI for the best race sim ever, especially to the both Daves, for good advise and help! 

Happy Racing all, come to chat in Yahoo Viper Racing Club and let's burn some rubber!

This program was produced without using or abusing animals. No user-servicable parts inside. Use no hooks. 