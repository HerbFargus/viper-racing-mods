(low poly version)

Name: Cathedral Canyon, after a canyon in S. Utah.

Usage:

Unrar contents into your game's Data folder. Replace Sunset Mesa, using Trackman.

Special Thanks: 

Sucahyo's helpful programs and problem solving, rVipeRacer's help with wall-making, and Megahurtz' textures.

Made by: 

Charles
cnummelin@yahoo.com
1.27.2008