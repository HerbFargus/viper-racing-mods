*******************************************************************************
****************                Queensland v1.0                ****************
*******************************************************************************

Readme:	Queensland Track for Viper Racing
-----------------------------------------------------

Track Info:

Location:	Australia
Length:		3.2 km 

-----------------------------------------



Created by:
------------
The AVRA group initiated the finishing of this wonderfull conversion by Tappethead :)


Special thnx to:	Ashes48, FPWolf, Andy M, Andy G, Tyler B, Anders,
			xtonyx, Dave B and Dave P

 



Installation:
-------------

 -(If you don't already have it) Download "Trackman" from the URL below:

   http://racingwolf.vroom-club.com/
 
 -You also need the 1.2.1 patch to run addon tracks! (recommended patch 1.2.4)

 -Unzip the Queensland_01.zip to your "Data" folder of Viper Racing (or extract the files there manually)

 -Run "Trackman" and swap the new (Queensland) track with an existing track (recommended: Dundas)

 -Start Viper Racing and select the track in the menu (it has a new picture etc.)

*NOTE When you want to race the track online you have got to make sure the other 
 players have swapped the new track with the same existing (old) track.


AI installation:
----------------
See new AI addon-Pack on www.vrgt.com


AI installation for in VRgt Demo:
---------------------------------
Copy the aidriver.adr file to your Viper Racing Demo/Data/ -folder (make sure you remove this when you want the AI for Assen to drive ok)


Updates:
--------

 Keep an eye on the Sites below to check if there are any new versions/updates available!

 http://avra.freewebpage.org/



Greets and have Fun!

