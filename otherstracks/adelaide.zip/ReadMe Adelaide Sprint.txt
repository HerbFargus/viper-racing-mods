Adelaide, converted from GPL Track Adelaide 2002 Sprint Circuit by Jim Pearson

Converted by Sucahyo (http://gt.cellphonespec.com/) for Viper Racing
With modification:
- bad poly fix
- invisible wall
- VR AI path & reset path
- texture merging
- added grass



Original readme:
====================================================================================================================
ADELAIDE 2002 SPRINT CIRCUIT FOR GRAND PRIX LEGENDS by Jim Pearson     http://www.jrpearson.homestead.com/index.html 

This is my version of the Adelaide Street Circuit as it is currently used by the Australian V8 Supercars and other classes in March each year.

If you look at the track map you will see where this circuit differs from the Grand Prix Circuit that I did as a 1967 retrospective and on which the real F1 drivers like Ayrton, Nigel, Alain and Nicki raced between 1985 - 95

If you drive my GP version you will see Bartells Rd [Adelaide Straight in This 2002 Circuit] going off to the right as you aproach Markets Kink and again to the right 2/3rd of the way down Brabham straight.

Where Adelaide 67 was a real driving experience set in a fictional 1967 setting, this circuit is designed to be as true to current reality as possible.

I decided to build it because of the introduction of the new Dunlop Sweeper which eliminated a chicane and makes the track come alive for the touring cars and I thought it would be a real hoot in GPL. If the touring cars can have a 230kph "sweeper"
at Adelaide why cant we?

So I went to the race on Saturday this year [2002] and then took digital photos of all the advertising ,gum trees etc on the following tuesday, All the adds you see in the track are the real thing [with the exception of a slightly modified Adelaide Promo] and placed as near as poss to where they were on the track that weekend.

Amoungst the things about the track that are different to the original release of Adelaide 67 GP Circuit are;

-Senna plaque inside left of the chicane, mounted on the wall not set in the grass as it is in real life, so you can read it.
-Furrows in the gravel traps 
-Tyre /wheelspin marks in the pits and on the starting grid 
-Pit workers and fire marshals
-Waving flags 
-Better Asphalt textures
-Replica road markings
-3D look curb textures
-Realistic broken asphalt grass /gravel verges
-Paint scrapes on some of the plain curbing
-Dirty/Used look to the bottom of the pit garages and the track barriers
-Replica road markings
-Supercar length starting grid
-Real gum trees
-Tree shadows
-Darker textures on south facing walls
-Shadows under the bridges

I also tried to put in wire mesh behind the barriers. This looked good at a standstill and when driving slowly, but was almost invisible when racing, so I left them out because their size and transparency gave too big a frame rate hit to be worthwile.



REMAINING CONTENTS

1 Acknowledgements
2 Manual Installation
3 Fuel Consumption - A word of CAUTION
4 Driving Tips and Default Setups for Adelaide
5 Frame rate issues
6 Build Philosophy/Authenticity/Realism/Cheats
  A. Brief History
  B. How best to depict the Adelaide Street Circuit?
  C. Build Philosophy
  D. Driving Characteristics - General 
  E. Driving Characteristics - Specific
     (a) TRACK WIDTHS
     (b) ELEVATIONS
     (c) CAMBERS
     (d) CURBS
     (e) CHEATS
     (f) The "MATTI COOPER GAP"
     (g) The "LEADFOOT LIZARDMAN RUNDLE ROAD STAND"
     (h) TRACK MAP NAMES/OMISSIONS.




1 ACKNOWLEDGEMENTS

I wish to thank the following people who made valuable contributions to the original GP 67 Circuit and to this follow up version.

Alison Hine for her encouragement and interest from the beginning and for her feedback on several early Beta's.

My original Beta Test Team who helped me to stand back from the project and then add further refinement and quality. Thanks a lot Guys.

- 'Leadfoot Lizardman' aka Peter Brain
- Steve Burnett
- Andrew Smith
- Matt Cooper
- Steve Churchward
- 'Coops'
- Harry 'Havago' Harkness
- Garry Watson
- Luke McLean

My Pre Release Test team for this version

- Peter "Lizardman" Brain
- Mike Farrar
- Leon "Hyperman" Jarvis
- Calum Ballinger

Mark Beckman, who is a godsend to many new track builders like me because of his constant support of those who frequent the Editors Forum looking for solutions to the many frustrating problems that confront us.

The GPLEA, [especially guys like Guru and Martjin], Legends Central and their associates for creating the tools to complete such projects and the Forums in which to discuss them.

Racesim for hosting.

Jay Beckwith for his Hi Res Sky

2 MANUAL INSTALLATION INSTRUCTIONS


PLEASE FOLLOW ALL OF THE FOLLOWING STEPS [A] to [E] EXACTLY. 
[F] IS OPTIONAL LOL :)

[A] If you are not using the installer, you will need to add the following lines, exactly, to your season.ini file in GPL

Add the same lines to your GP.ini if you want Adelaide to be a round of the World Championship.


[EventXX]
name=Adelaide International Trophy
shortname=Adelaide International  Trophy
trackDirectory=Adelai02
numberOfLaps=88
day=16
month=3
startingGrid=4


 
As you may know, xx is the next unallocated number but GPL wont accept more than 64 active tracks. Don�t forget to increase the total number of tracks at the top by one.

[B] Rename the 'rpy' file to JP 1 21 44.rpy and put it in your C:\Sierra\gpl\Replays folder.

[C] Rename the 'dat' file to 'Adelai02.dat' [ yes use a capital A, carefull with the spelling ] 

[D] Then open a new folder in your GPL tracks file and name it Adelai02 [Capital A]

[E] Drop the remaining CONTENTS of the unzipped file, including the renamed Adelai02.dat file into the Adelai02 track folder, close it, then charge off to the chicane for your first sighter lap. 

[F] Do try to keep your eyes on the road, there are a lot of people about out there :-)



3 FUEL CONSUMPTION - A WORD OF CAUTION ! 

One of the curious things about GPL is that while the individual makes of AI cars have different rates of fuel consumption, and track builders can set appropriate fuel usage rates in the track.ini for them, PLAYERS' cars all have the same rate of fuel consumption per mile/km regardless of make or track. 

Adelaide can be rather heavy on fuel depending on your driving style, so watch your fuel consumption in practice and overfill your tank until you get used to how much fuel you use in different length races. 

4 DRIVING TIPS AND DEFAULT SETUPS

Adelaide has some unique characteristics. I have driven it a lot during building, and while I'm not the fastest driver [ GPL Rank -33 ] I thought I would stick my neck out and pass on a few tips/relevant reminders to help the average to slower drivers maximise their track familiarisation experience.

-Firstly, try the default setups I have developed, which are based loosely/closely for several cars on some G Huttu fundamentals, until you are sure you can import or develop  better ones. These will get you started. Simply adjust the fuel load then fine tune your tire pressures to suit your driving style.

-The Default setups have reasonably conservative/stable diffs/clutches but fairly low front brake bias. They are made to be stable under power and braking but have reasonable turn in to corners. They won't be the absolute fastest setups out there but they should help you stay on the track and enjoy some CONSISTENT RACING. 

The reason for the low front brake bias is that with higher bias it is too easy to lock up the fronts at the end of Brabham Straight, which cooks the fronts and makes the car understeer around the hairpin.

-In my view, the most important things to do at Adelaide are:-

*Use all the track width to get better turn in angles [do what you think is a good lap, save it to replay, then watch it in F10 view or an overhead view and see how much more of the track you could have used and count the number of apexes you missed! ]
 
*Hit ALL your apexes - You will be able to do this in the twisty East Terrace section only if you exit the previous corner on the proper racing line, rather than run wide. ie get one corner wrong and you upset the flow of the circuit.

*Brake early enough to GET THE CAR SLOW ENOUGH TO GRIP the inside of the corner. SLOW IN/FAST OUT is better than FAST IN /SLIDE AWAY FROM CORNER/ MISS APEX / LINED UP WRONG FOR THE NEXT CORNER.....  DIG?

*Remember that Adelaide has a lot of road where you can only use PARTIAL THROTTLE if you want to flow smoothly around it and get the best time. The accelerator can't be used as an on/off switch here. Feed in only as much power as the car can handle and watch your lap times tumble.

*Try this technique to get better rotation into the corners [Especially useful in East Terrace and at Brewery Bend - see Track Map in Program]

- Brake normally for the corner. 
- When the car is slow enough and under control, start your turn in. 
- BY this time you would be using less brake and no/ not much accelerator.
- Lift off both Brake and accelerator as the car starts to aim for the apex, make sure the fronts are gripping not sliding, then give the brake a sharp on/off tap. 

With the default setups and the brake bias built into them, you will find that with a little practice, this brake tap with a stable car will give you an extra 10 - 20 degrees of 'turn in' just when you want it and allows you to hit the inside curb/apex, use all the road and accelerate with a nice four wheel drift out of the corner. :)

5 FRAME RATE ISSUES

Based on Beta testing, both Adelaide circuits should give you frame rates as good as most add on tracks.  You will suffer some frame rate hit at the back of a full field of AI on the starting grid, and just after the start at the Chicane, especially if there is a bingle, but your frame rates should be acceptable for the rest of the first lap and stay around 33-36 thereafter..

The tighter corners like Brabham straight Hairpin give some momentary "hit" if there is an accident or you spin. This is no different to the Hairpin at Snett 67 for example.

Turning down/off  Detail Bias, Environmental Effects, Track/ Mirror detail can help.

Known issues:

- Adelaide shows much better frame rates for Voodoo 5 cards using antialias settings and Voodoo 3 cards, if you use the George Smiley Glide Patch available at the US Pits'  GPL 'LINKS' Page. AND YOU USE THE CENTRAL MIRROR OPTION/MIRROR REFRESH EVERY 2/3. 

Using the central mirror with antialias 2x or 4x can improve frame rates by an average of 10 !!

- BE CAREFULL when installing this patch. There are three files in it but one of them is a dll "system" file which will be invisible unless you have selected "show all files" in your  "My Computer" - To check, open "My Computer" then click on the view bar at the top; run down it and click on Folder Options then click on the View  tab. Then click the option that says "show all files" under the Files and Folders/ Hidden Files section.

By all means follow the instructions that come with the Zip, but note that some people can only get this patch to work by putting BOTH the Glide.ini file and the dll file in their main GPL folder !

-Cars/Carsets have some effect. Even two of Bruce's wonderful cars, the Brab and the Lotus can give you different frame rates by 2 or 3 frames at the back of the starting grid.

-Sadly, The Gplea Eagle and Honda seem also to give some a disproportionate "hit" when they appear in your mirrors.

 

6 BUILD PHILOSOPHY / AUTHENTICITY / REALISM / CHEATS [ FROM THE ORIGINAL GP 67 VERSION README  FOR REFERENCE ]

Here are some notes on the Adelaide Grand Prix Legends track to help you understand what I have made and the 
philosophy behind it.

A. Brief History

The Adelaide GP street circuit was used as the first Australian Formula 1 venue between 1985 and 1995.  Bigger dollars then enticed the round to Melbourne, a good circuit, but not a street circuit and not as much a favourite with the drivers as
Adelaide.

One of the reasons Adelaide was a favourite venue, was the small scale of the city and the parklands that entirely surround the central part of the city and inner city residential precincts. Also of interest was the unique Federation style of architecture and stone construction of many of the buildings, including many that line the track.

B. How best to depict the Adelaide Street Circuit?

The trouble with trying to recreate the Adelaide track as it was in 1995 when the last GP was held, or as it was in 1985 when the first one was held, or as it is now #, is that modern safety regulations dictate such high concrete barriers and other safety fencing, that much of the visual appeal of the track surrounds are lost. The GP3 addon version of the track shows this.

[# Touring car races are still held annually on a shortened version of the circuit, turning right at Bartells Rd and cutting out the last part of East tce, Rundle Rd and over half of Dequetteville Tce. You can see Bartells Rd disecting the GP track vertically on the track map included on page 2 of the program ]

The GRAND PRIX LEGENDS 1967 Formula 1 simulation provides the perfect opportunity to showcase the driving characteristics of the real full length GP track and also depict the local environment, by creating the track as it would have presented, if it had been a round of the Championship in 1967 the week after Mexico. Accordingly, that was my overall goal.

C. Build Philosophy

To create a circuit to faithfully copy the long version of 1985, with accurate length, rise and fall, corner radiuses, cambers, temporary curbs and runnoff areas. This was done using a 1/2500 arial photographic map with 2 metre height gridlines, 300 digital still photographs and close observation and note taking of all the cambers, curbs etc; which 
required walking the entire course three times. 

I think the results are very accurate, for example, the recorded length of the real track is 3780 metres and the draftedaggregate centreline length of the 95 track sections which make up my replica is 3781.5 metres.

While I have softened the track surrounds and used lower barriers, I tried to preserve the driving characteristics of the real track. If when driving the real circuit, you would hit a hard surface, or run into a gravel trap, or fight for
traction, or get airborn over a curb at a particular point, then that has been replicated.

Visually, I recognised from the outset that the use of existing graphics from other tracks was innapropriate, because the available buildings have the wrong facades and the trees are mostly northern hemisphere conifers/ deciduous types and entirely the wrong colour. 

While there are some tall conifers along the track, predominantly the trees are varieties of Gum trees [Eucalypts to some] the foliage of which have a lighter bluish hue. The light grey trunked Ghost Gums on Wakefield Tce being the most striking. 

That is why I have constructed my own scenery Mips using digital Photos as the base. A huge and painstaking task, but one I think you will agree is well worth it when you see the results. Adelaide is an ideal track to test out this technique.  

I have also taken care to wash out the harsher colours of some graphics, to better represent the effects of the strong Australian light. I hope that any third party developers out there who may be tempted to "enhance" these graphics in the future bear that in mind. eg If you dont know what colour Kikuyu Grass is when its starting to get a lot of sun, think twice about fiddling with my mip !

The curbs are such an integral part of the Adelaide circuit but pose something of a dilemma. As the circuit is to be a "retrospective" set in 1967, should the blue and white FOSTERS colours from 1985 be used? or the current South Australian linked colours of pale yellow, red and blue, some other colour that might have been in vogue in 1967, or just plain white? 

So I made two curb Mips and origionally favoured the Fosters blue and white, because it was plain and historically linked to the first Grand Prix in 1985. However, now I have got the correct soft colours and low contrast into the "three colour"Mip, I tend to favour that, simply because it looks so striking. In any case, you have a choice, for I have included
both Mips with the release and those who bother to read this Readme will discover that and be able to try them both!


D. Driving Characteristics - General 

These are so important and need a bit of explaining to anyone who has not been to and walked the Adelaide circuit. 

If you have only seen the circuit on TV or Video, it is usefull to remember that any television picture of an object renders it in two dimensions and therefore flattens it out. eg in golf, the greens at St Andrews have much more slope
than they appear to have on TV. 

The Adelaide GP circuit is no exception. 

The real elevations in metres above sea level are, 49 at the S/F line, 42.5 just before entering Wakefield St, 48 just before Wakefield St enters the first right hander into East Tce, 46 at the second [LH] bend in East tce, 48.5 at the next RH bend, 42 at the Rundle Rd cnr, 40.5 at the lowest point of Rundle Rd, 51 halfway along Dequettville Tce, 
decending to 48 at the sharp LH into the racecourse and rising half a metre in the first part of Pitt straight. 

So a fair bit of rise and fall is what you would experience if you drove the track. You can actually drive most of the circuit, some of it the wrong way, because of course they are real streets.

A special note on cambers is required. When I first built the circuit it was almost undrivable with the GPL physics engine because there was so little grip. Corners like the first right hander into East Tce, in reality, have only a few centimetres of positive camber on the very inside and negative camber on the outside. In other words the corner
has convex camber. 

To help the cars handle as they clearly do in real life [1967 F1 cars, including a FerrariF312, Brabham BT24 and 2 Lotus 49's have raced  on the shorter circuit as Formula Adelaide up to last year [2000]], I have built in some positive camber into all corners, although when you are sliding furiously away from the apexes you will curse me for not putting in more. 

Corners like the two hairpins at the end of Dequetteville Tce {also known as Brabham Straight} and at the start of Pitt Straight are essentially flat in real life. The most interesting one for camber is the left in the L/R combination in East Tce just before Rundle Rd. In reality it has NEGATIVE camber, but I have put a little bit of positive camber in 
it to aid transition. I think you will agree though, after driving it fast with a balanced setup, that you are still fighting for grip with that RHF tire and you need an early turn in to make the left apex properly.

MY OBJECTIVE WAS TO RETAIN A REALISTIC DRIVING EXPERIENCE BUT MAKE SURE IT WAS STILL FUN.

  
E Driving Characteristics - Specific

(a)TRACK WIDTHS -  I have made this track with 6 different track widths to reflect the real driving experience. 
- The Racetrack Section between Racetrack Corner and Pit Straight Hairpin is The narrowest at 10 metres. 
- Most of East Terrace and Rundle Road is 12 metres.
- Wakefield Road is 13 metres. 
- Pit Straight 14 metres. 
- The top part of East Terrace before Markets Kink is 16 metres.
- The widest part of Brabham Straight is 32 metres, with potentially a lot of drafting and    outbraking manouvers to be performed before too long !! :)

(b) The ELEVATIONS [general rise and fall, not the cambers] in my track file match to within 1metre, the real elevations shown on an Arial photographic map. 

(c) The CAMBERS are a compromise between the real ones and necessary modifications to account for how GPL cars behave with the GPL Physics engine. 

(d) The CURBS are also a compromise between the height/steepness of the real ones and the height/ steepness required to get the GPL cars reacting properly to them. 
You should be able to ride them a bit but accept that they will unsettle the car. 

However you shouldn't be able to drive right over them without some consequences !

Too low and the GPL cars just cruise over them at speed, which ruins the proper reactions of the cars to riding curbs like the ones at the Chicane or at Brewery Bend.. This also broadens the racing line making the track unrealistically easy, far less technical [and more conducive to accidents if the racing line is too wide and fast ].

Too steep and curbs like the ones on the outside of Stag corner and Brewery Bend will trip up and overturn the cars, or bottom out and damage the cars in the case of running through the chicane.

I have experimented with the height of all the main curbs. You may think one or two of them too severe, but I can assure you that set any lower, you would suffer little if any instability driving right over them, which would completely ruin the way the track should behave !

(e) CHEATS. There are obviously places where potentially, people could cut corners or drive outside curbs to gain an advantage. I think I have all these covered.  

Perhaps the fix that might create the most discussion is that the track surface outside the external curbs at both Stag Corner and Brewery Bend is concrete with an asphalt texture mapped on it. This gives a slightly more slippery surface, like you get when you drive off the racing line onto dusty tarmac.

I have also included a short section of dirt surface with an asphalt texture at the very beginning of the outside exit curb at Stag Corner, to slow down those who completely miss the corner or those who try to cheat by driving right around the outside near the wall at speed. The concrete surface wouldn�t arrest this cheat enough. However, if you intend to drive the right line but just overcook it on exit and go over this curb, you will be far enough down to be driving on the concrete surface.

At Wakefield St there is potential for Wall riding or Wall Bumping, so I tried different or no barriers there. It just wasnt realistic enough, so the concrete returned, but with slight imperfections where track sections join to unsettle cars wall riding. In any event, extended wall riding there is just SLOW !

More of concern was what I call "Wall Bumping" where you come through the left hander from the Chicane full tilt and bounce off the wall at the intersection with the fast line. I have tested this and that too seems slow, by about 5 mph over someone taking the normal fast line.

(f) The "MATTI COOPER GAP" is the name of the last minute inclusion of an overlap gap in the outside concrete barriers at Stag Corner. This gap is for track re-entry, catering for those with the most daring driving style who launch themselves at full speed up the outside entry curb at Stag and find themselves airborne, then touching down on the wrong side of the barrier ! 
I'll leave you to guess which one of my Beta testers discovered this little detour !

(g)The "LEADFOOT LIZARDMAN RUNDLE ROAD STAND" is the second one in Rundle Road. I have named this in honour of PB because he has been a great help through the Beta testing phase and because he used subtle persuasion until I included a stand that he used to always sit in to watch the racing during Adelaide's F1 years.

Also as a consolation because I refused to include the name "Senna Chicane" on the Track Map at the end of Pit Straight [ See next point] 

(h) TRACK MAP NAMES/OMISSIONS. I have used the name Brabham straight in my map because even though this is a retrospective 1967 circuit, if an AGP had been held in that year at Adelaide, it is plausible to use that name because Sir Jack had won the World Championship the year before for the third time. In my view it is logical that he would have been so honoured, even though still racing. 

Despite having the greatest respect for the records of both Alan Jones and Ayrton Senna Da Silva and despite regarding Senna as the best of the modern era, including all those currently racing, I haven't used the Jones Straight [Rundle Rd] or Senna Chicane names. This is because in 1967 jones was still to make his mark and Senna 7 yoa. I wanted my Program to reflect the period.

Well thats all Folks !! I wonder how many people will bother to read all this LOL

To those who have got this far, I hope you enjoy my small contribution to the GPL community.

Cheers

Jim Pearson.

http://www.jrpearson.homestead.com/index.html



 


