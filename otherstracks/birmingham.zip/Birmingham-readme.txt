Birmingham, converted from GPL Track Birmingham scratch build by Pirenzo (William Campbell).

Converted by Sucahyo (http://gt.cellphonespec.com/) for Viper Racing
With modification:
- bad poly fix
- invisible wall
- VR AI path & reset path
- texture merging, 500+ texture down to 101 !!!
- many graphical glitch fix
- adding inside and outside grass

Sky by JC (http://games.groups.yahoo.com/group/vroviperracingonline/)


Original readme:
====================================================================================================================
The project was begun in around June 2005. Initially it was just a distraction from the final work that needed doing on Belle-Isle Full Circuit to make it release worthy. Given that I was to start university in Birmingham that September it was inevitable that this would become my next project, albeit a solo project this time, and a real track rather than fantasy.
Although a great deal of the major ground work was covered in the first 12 months, inevitably distractions in my university life made progress quite slow, and indeed in recent months, my interest in GPL has waned to the point that finishing the project became a race just to get the damn thing out of the way!




*~*~*NOTES*~*~*
The track should be completely Voodoo compatible. However lower end systems (such as mine!) should expect some frame rate issues, and even for some mid-range systems there is one area where a minor frame rate hit has been reported.
Although I generally don't prescribe to building tracks with such an enormous amount of detail and high resolution that only a minority of users can drive them, given the nature of the layout, some extremely long draw distances are inevitable. In any case, I have packed the track with some helpful, if not particularly pretty, addons to help the frame rate.
I did experiment with some other methods of achieving the required views, but generally I found that while minimising the actual frame rate hit a little (by 2-3fps), it merely extended the drop to the entire section of track for which either of the two straights were in view, some 45 seconds of lap time.
I do appreciate that the track is far from perfectly sorted in some places. On the other hand it is an extremely complicated environment to model, and I have given it my best shot to sort out most of the problems (at least from the driving view and from the TV cameras).

*~*~*CREDITS AND ACKNOWLEDGEMENTS*~*~*

Textures, Information and Help

    * David Page, information and photos
    * Martin "MECH" Huiskes, for the AI
    * Scott Stark, people rows, base horizon and shrubs
    * Eric Bourgouin, trees (inherited mostly from Belle Isle)
    * GPL Repository, Ten-Tenths, AtlasF1 Nostalgia forum, SimRacing Mirror Zone
    * SRMZ staff for testing and encouragement
    * Bill Cooper for hosting

Programs

    * Phil Flack, GTKAlt, GTKMaker, GPLAnim, File Formats, GPLEditor, Trk23doZ, sciss
    * Christian Wohlfahrt, OneTwo3DO
    * Klaus Horbrand, WinMip2
    * Dave Noonan, 3doEd
    * Stefan Magnussen and Lee Bowden, SRB Mini 3do Editor
    * Stefano Zampedri, GPLWallChanger
    * Neil McCollum, Single Altitude Formula
    * Raihan Kibria, FrHEd



I shan't be too upset if people go and make high resolution texture packs for this track. On the other hand, if you feel compelled to go and do this, I'd appreciate it if you actually made a proper job of it, and not just throw your first generic tarmac and barrier textures at it just because it looks better on your super size monitor.

William Campbell, 24.02.2008