Daytona Roadcourse, converted from NR2003 Track Daytona Road Course work by FOZ, scratch build by Smokey.

Converted by Sucahyo (http://gt.cellphonespec.com/) for Viper Racing
With modification:
- bad poly fix
- invisible wall
- VR AI path & reset path
- texture merging
- remodelled inside grass to avoid overlapping
- reduce polygon of ferris wheel
- change cone to wall


Night sky by JC (http://games.groups.yahoo.com/group/vroviperracingonline/)


Original readme:
====================================================================================================================
--------------------------------------------------------------------------------

DAYTONA RC FRL (Fasturd Racing League)

--------------------------------------------------------------------------------


GENERAL INFORMATION:

Trackname:		Daytona RC FRL
Version:		1.0
Year of creation:	2006
Racing sim:		NASCAR Racing 2003 / GTP
Author:			Greg "FOZ" foslien
Email:			foz@fasturd.com
Website:		www.fasturd.com

--------------------------------------------------------------------------------


DESCRIPTION:

This is a refresh of the Daytona Road Course track originally created by Alex
Ulleri, aka Smokey.  I have updated the track from the original version, to
reflect the many changes to the track since the original. 

Here is a list of the things that have been changed:

+ infield track smoothed to reflect new surface, and changed ini file to reflect
  the additional grip of new surface. I did this by making the infield course as
  concrete material, but kept the asphalt surface.  This allowed the ini file to
  adjust grip of concrete only.

+ smoothing of entrance back onto main track from the infield course... no more 
  big bump when you hit the banking in main track Turn 1

+ adjusted rumble strips in infield to be smoothed out and wider, 
  created more run off coming out of T3 to the left for more passing room
 
+ widened yellow rumble strips to be 5 feet wide all the way around infield

+ put in elevation change over rumble strips on the outside of Turn 3 where it 
  merges with service road

+ shorted "triangle" of rumble strip at T3 and service road

+ put 300, 250, 200, 150, 100 foot markers on back stretch before bus stop

+ added some gravel to penalize cars that cut bus stop exit

+ made entry onto bus stop longer & added sections to allow for a "curved" look

+ changed rumble strip location on exit from bus stop

+ reset yardage markers on back straight to correct yardage

+ added more cones to show bus stop

+ added bumps to gravel section coming out of bus stop to make less desirable path,
  not enough to upset car into a wreck, i think, but rough enough to get someone 
  nervous about driving there 

+ added SAFER barriers to track

+ added invisible wall in infield inside Turn 5

+ added a ferris wheel to the infield

+ updated some of the infield buildings

+ added some SSCA logos to walls

+ repainted curbing mips to match yellow hue on other sections

+ changed fence area to be farther back in Turn 3 and kink

+ changed stands in Turn 3, Kink, and Turn 5 

+ updated SSCA logo on billboard 

+ updated braking signs to 100, 200, 300 instead of 1,2,3

+ changed back of braking signs to have new SSCA logo

+ added SSCA logo to large wall entering pits 

+ added SSCA logo to infield grass

+ added Daytona logos with flags to SAFER barriers

+ added updated PEPSI building in pit area 

+ reworked the textures, skew, orientation of mips on back straight where changes
  were made to bus stop. Grass lines match up, and textures look better against the 
  road surface

+ CAMERAS.....CAMERAS..........CAMERAS... I left the original cameras on TV1 alone, 
  but I reworked all of the TV2 cameras and the spectator cameras. Spectator cameras 
  are a combination of sitting in the front straight area , cam 2 is sitting in the
  ferris wheel where you can watch the entire infield road course, the Lake Loyd view
  of the bus stop, and  a Turn 4 campertop views.  Some of the views are for enjoyment, 
  and some are specifically designed to race admins.

+ put up cones to mark penalty box in bus stop

+ ini file changes for the penalty box

 

--------------------------------------------------------------------------------


INSTALLATION:

NR2003: Copy the "Daytona_RC_FRL" folder into your NR2003 tracks folder,
GTP: Copy the "Daytona_RC_FRL" folder into your GTP trackD.


--------------------------------------------------------------------------------


KNOWN BUGS:

None known at this point.


--------------------------------------------------------------------------------


OTHER ISSUES:

none that I am aware of

--------------------------------------------------------------------------------

CREDITS:
Greg Foslien		Sandbox work
			Additional textures
			Trackside objects
			Textures
			Cameras

Brian Wagner		Update ideas and guidance
Daring Gangi		Update ideas and guidance	

Fernando Medina		LP Lines, Rolex race photos
Brian Wagner		Rolex race photos			

Darin Gangi		Testing and feedback
Brian Wagner
Chrstopher Hughson
Fernando Medina 

Alex Ulleri		Original Daytona Road Course track


--------------------------------------------------------------------------------


THANKS TO:

Papyrus Racing Games	NR2003 and Sandbox
Redline Develompents	GTP
Klaus H�rbrand		WinMip2
Fred Anderson		3ds Max PAS export plugin
Hillcrest Racing	borrowed some textures from Elkhart and the base for new
			billboards.
Dave Noonan		Used the 3DO tools from his set of programs to create
			new billboards for this track

Sunsky track Ferris Wheel, not sure who created that track, the author did not
create a readme file, but I used his Ferris Wheel and repainted it to look
more like the Daytona Ferris Wheel.


--------------------------------------------------------------------------------


SPECIAL THANKS:

Darin Gangi and SSCA for a great time endurance racing
Sim Racing Connection for keeping the sim alive with track lists
STRL and Jeff Christianson for a great place to race cup.
US PITS for all of the tools on their site for creating tracks.
Hillcrest Racing for the great objects from their spectacular tracks.


--------------------------------------------------------------------------------


DISTRIBUTING WEBSITES:

Fasturd Racing League:	www.fasturd.com

--------------------------------------------------------------------------------

AGREEMENT OF USE:

Use of this track by installation into a racing simulator constitutes agreement 
with this and the following statements:

1) This track may not be sold or distributed for commercial purposes, or money 
exchanged for this track or any part thereof.

2) This track may not be redistributed without written consent of the original 
author, with exception of the sites listed above. 

3) This track cannot be modifed without written consent of the original author.

4) Pieces of this track (not including the .ptf file) may be extracted and used for 
other tracks, but cannot be used in projects for commercial purposes, and credit 
to the original author should appear in a readme that is distributed with the new project.

5) This track must always maintain an unmodified copy of this readme in whatever form it
is distributed.

6) This track is covered by implied intellectual property laws, in that all original content
is the property of the author. All other content is the property of the respective owners.

7) This track is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
USE AT OWN RISK.

--------------------------------------------------------------------------------

