Kyalami, converted with permission from Steve Life (http://www.stevelife.com/) GPL Track

Converted by Sucahyo (http://gt.cellphonespec.com/) for Viper Racing
With modification:
- bad poly fix
- texture merging
- invisible wall
- VR AI path & reset path


= = = = = = = = = = = = = = = = = = = = = 
Steve life readme:

STEVE LIFE ROUEN 7.0
Historic Photo-Real
Files by Klas, Seegert, Photo-Real files by Steve Life