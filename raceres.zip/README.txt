<<<<<<<< backup your race.res First!!! >>>>>>>>>


how to install,        unzip the race.res to your  Sierra / Viper Racing / Data  folder.

____
note:    the new wheels work on all of the cars, becouse thay all use the same wheels :)   
 this was a very hard thing to do,   took me 24 hours to make a template to go by  dang nabit 
so i hope yea like em :)