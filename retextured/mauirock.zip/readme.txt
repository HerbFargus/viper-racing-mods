Maui Rock

New texture for the track Rock Island in the Viper Racing game

This is only a re-textured track for those who want a new look after having played the game for a long time. It can't compete with nor can it be compared to the fantastic new tracks made by Tony and Brett, because their tracks are completely new 3D models, while i only changed some pictures and did not touch the 3D model at all.
Also, this re-texturing can not compete with the wonderful work Ashes48 did on the Wintergreen track, the re.texturing of Castlegreen. Wish i had his eye for good looks and his graphic skills...

Maui Rock is totally compatible to Rock Island, it can be used online together with Rock Island, i.e. there will be no problems if some of the competitors use Rock Island original and others use Maui Rock (just as with Castlegreen and Wintergreen).

Installation is quite easy and can be done in 2 ways:

1) Manual installation:

Back up your original Rock Island track. It is called kenyon.trk. Find this file in the game's Data folder using Windows Explorer and rename it to something like kenyon.old or the like. Then extract mauirock.tra from the zip to the data folder and rename it to kenyon.trk. Now start the game and select Rock Island, you will race in the new environment. All records like best lap times, high speeds etc. will be saved as if driven on the original track.

2) Automatic installation:

Unzip all 3 files mauirock.tra, mauirock.jpg and mauirock.stp to your game's Data folder. Then use my program TrackMan to load Maui Rock into Rock Island (see instructions that came with TrackMan). Now you can see Maui Rock as track and select it in game. All records like lap times and top speeds will be saved separately for this track, and not mix up with the original Rock Island records.


De-installation runs in reversed order to above:

1. If you installed by hand, remove by hand, i.e. delete kenyon.trk and rename the original file, which you renamed to for instance kenyon.old during installation, back to kenyon.trk. That's all.

2. If you used TrackMan to install, just click reset in TrackMan, and you're back to defaults.

NOTE: Never install any updates of addon tracks when they are activated in TrackMan, first reset all to default tracks, then do any copying or unzipping to Data folder! 

Credits: Thanks go to Tony and Brett of the VRgt track making team for all their valuable work on new tracks, to Franco for the stp2tga program, and to the 2 Dave's from MGI for all their help in unveiling the secrets of Viper Racing. Also thanks to the Hawaii tourist board for supplying the fine pics for some of the textures.

Programs used: Paint Shop Pro 5 and 8, Thumbs2000, MS Photo Editor and the Viper tools rescrack.exe, mkres.exe, mktex.exe and mkstamp.exe.

Blame all bad and ugly things you might detect on me, and if you do like the look, praise MGI for having written the best race sim in the world.

No user-serviceable parts inside, do not expose to open sunlight, handle with care, use no hooks. No animals were used for making or distributing this product. Don't trade as XXX movie on file sharing systems!

Frank P. Wolf

http://members.aol.com/racingwolf999
fpwolf@aol.com