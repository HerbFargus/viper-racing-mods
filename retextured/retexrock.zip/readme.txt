Retextured Rock Island

Most of the textures were made by Tor from the Racer Community for his tracks. Alittle editing to them was done by me though.

NOTE: Back up your Rock Island file(Kenyon.trk) before installing this one just incase you prefer the old one or incase you find a problem.

Track: Viper Racing'
Textures: Tor:
          KonArtist: