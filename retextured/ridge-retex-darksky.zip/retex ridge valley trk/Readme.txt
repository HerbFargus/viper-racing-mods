Retextured Ridge Valley Track

File name is "hastings.trk"

Find that one in Viper Racing "Data" folder first...
cut and paste it into a folder called "original ridge valley track" somewhere in "my documents" just in case you don't like this one.

Then copy or cut and paste it into "data" folder.

Done!Enjoy...
Greets:)
