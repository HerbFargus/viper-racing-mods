TrackMan - the track management program for Viper Racing   Version 1.2beta

This program was designed to manage new addon tracks for Viper Racing (VR). The track names are hard-coded in the original Viper files, and so can't be changed. Therefore, new tracks have to make use of these names. The most simple way is, renaming the old tracks to something else, and rename new tracks to the old names. This can be done in Windows Explorer of course, but you will soon mix up what track was what, and your Viper Racing\Data folder will become a mess. Here is where TrackMan comes in handy.

What the programs does: 
it changes the name of the original tracks that you don't want to use for the next race session from say, bemidji.trk to bemidji_AS_oval.btr, and renames the new track oval.tra, which you want to use in place of Bemidji, to bemidji.trk in a normal graphical windows interface, showing you a picture of the new track, so you can easily tell what is what. 
It also pastes the picture of the new track, that is shown in the selection screens in the game, into the ui.res, and adds the name of the new track to your language file, so that it shows in the game with the right name. All important files that are touched by the program are backed up first.
When you click reset, it restores all to your normal Viper tracks, so you don't have to remember file names and all.

For a short overview of how to use look at the picture TMhelp.jpg, that came with this program.

How to install:

1) Move all your addon tracks to the Data folder inside the Viper game, normally C:\Sierra\Viper Racing\Data. Make sure they all have the ending .tra. Also, put a picture of the addon track with same name, but with the ending .jpg, in the same folder, otherwise TrackMan will have nothing to show. Also put the picture notrack.jpg in this Data folder. Also put the file with the same name as the new track, but with the ending .stp into the same Data folder

2) If you keep any add-on tracks in this folder with a different ending like .new or .bak or any, then rename them to .tra, otherwise the program won't find them.

3) Move the file Trackman.exe in the same Data folder (important!).

4) Now start trackman.exe by doubleclicking, you see all your new tracks on the left, and on the right the buttons with the names of the original tracks.

5) Now select one addon track to use, and it's picture shows up, if you have a picture in jpg format in the same folder. Now click the button of the original track that you want to use as a host for this new track (you will not be able to use the original track in the following race session. Congratulations, you have successfully activated one new track.

6) Proceed so with all new tracks you want to use in your next racing session. You see that you will have to trade one original track for every new track you want to use. But this decision is of course only for the next session, that means, until you restore the original track by pressing "reset" or "reset all". The total number of tracks is limited to 8 in every case, this limitation is caused by the game and can't be changed.

7) Normally you will want to use a mixture of old and new tracks. You can easily see which old tracks still can be used (their buttons are black), and which tracks you traded for new ones (the buttons are greyed out, and you find the name of the replacing new track next to it).

8) To manage your cars and wheels in quite the same easy way, install CarMan and WheelMan from my site.

IMPORTANT: The program copies or creates some files in your Data folder (and also in the Config folder for scores). Please don't touch, alter or delete these files by hand, TrackMan only can work correctly, if it finds the backup files it has created. Especially files with the endings btr, trm and scb should be absolutely TABOO for you.

Troubleshooting:
Q: I click one of the buttons, and nothing happens, the tracks stay as they are..
A: Your tracks are possibly write-protected, and so can't be changed. Please use your Explorer to check which files in your Data folder are write-protected, and remove the protection (see Windows help if necessary).
Q: The left box is empty.
A: You have started the program from a location, where no tracks are stored. To work properly, the trackman.exe has to be in the Data folder of Viper, or it won't find nothing.

This game is freeware, use it at your own risk, there is no liability implied to any damages to your tracks or Viper game or other things whatsoever.

NOTICE: While all attention was taken to trap any user errors, try to avoid unsenseful or irritating usage. For example, if you run TrackMan, change a track, then race while Trackman is still running and afterwards move or delete some files in your Data or Config folder, don't be surprised if your Viper game ends up in a mess!!! Also, if you have some very important files like scores (*.sco), that you don't want to loose, it is always wise to back them up before.

Developed by Frank P. Wolf for the worldwide Viper community to promote use and racing of as many new tracks as you might wish.

For any questions or comments, good or bad, send me a mail FPWolf@aol.com, or visit my homepage http://members.aol.com/racingwolf999

Thanks fly to Tony (xtonyx), the king of trackmaking, for invaluable input and endless testing, and to Andy M., Andy G., Tyler B., Enigma_Incognito, Franco, Ashes48 and of course to Dave B. and Dave P.!

Happy Racing all, come to chat in Yahoo Viper Racing Club and let's burn some rubber!

This program was produced without using or abusing animals. No user-servicable parts inside. Use no hooks. 