12invrt.car  made from scratch for VIPER RACING  29 Jan 2018 BY:

VAL IN MOOSE JAW , SASKATCHEWAN , CANADA.

e-mail      val5662@yahoo.com

This car was built for anyone wanting to check a few short heights or widths of objects on any track.


PERMISSION INFO:
 If you want to convert this car to any other game go ahead...
.......BUT if you want to modify this car and keep it in Viper 
Racing , go ahead but please rename the car files so we dont have 2 cars with the same name.
Also if you want to use parts from this car , go ahead.
After all , it's only a game.
Thanks!
Cya on the track.
                 Have a great day! 
 