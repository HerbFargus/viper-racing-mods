Bells99.car  CONVERTED from Val's VR car Pauls99.car to VIPER RACING  15 Jan 2018 BY:

VAL IN MOOSE JAW , SASKATCHEWAN , CANADA.

e-mail      val5662@yahoo.com


PERMISSION INFO:
 If you want to convert this car to any other game go ahead...
.......BUT if you want to modify this car and keep it in Viper 
Racing , go ahead but please rename the car files so we dont have 2 cars with the same name.
Also if you want to use parts from this car , go ahead.
After all , it's only a game.
Thanks!
Cya on the track.
                 Have a great day! 
 