******************************************************************************************************************
********2004************   The Viper Racing Grand Touring Association Proudly Presents   *************2004********
******************************************************************************************************************


                                   --------------------------------------------
                     ------------------------------------------------------------------------
   ------------------------------     The 2004 Chrysler Viper GTS-R (VR GT1)     ------------------------------
                     ------------------------------------------------------------------------
                                   --------------------------------------------



-------
Credits
-------



Original 3D Source		                M@D69 
--------------------------------------------------------------------------------------
(madfactory.m4driving.sm)



* 3D modeling		                        Ashes48
---------------------------------------------------------------------------------------
(ashes48@comcast.net)  



Dash Model & Textures		                Ashes48, xtonyx, Ludwig & MGI
---------------------------------------------------------------------------------------
(info@vrgt.com - www.vrgt.com)



* Sound Files					Matthias "Matt" Nyberg
* Performance Files				Matthias "Matt" Nyberg
---------------------------------------------------------------------------------------	
(matt@vrgt.com - www.vrgt.com)



* Beta-Testing   				Brett "i814t" Walsh
-------------------------------------------------------------------	
(brett@vrgt.com - www.vrgt.com)



* Beta-Testing   				Graeme "Crash" Johnstone
------------------------------------------------------------------------	
(crash@vrgt.com - www.vrgt.com)



------------
Installation
------------

-Extract GTvip.car into your ..\Viper Racing\Data\ folder

-Start Viper Racing and select GTvip in the Options/Hacks section

-Select "Quickrace" or "multiplayer" 



-------------------------------------------
The Viper Racing Grand Touring Championship
-------------------------------------------

All cars provided to you by the VRGTA are specially build and homologated to be driven in the VRgt Championship. 

Statement of Purpose

�     The purpose of the Viper Racing Grand Touring Association is to re-vitalize and improve the Sierra made 
      Viper Racing simulation and to introduce people with interest in this game or online racing in general. 
      Most of our events and races are for competition purposes though satisfaction and camaraderie among friends 
      is the bigger reward in the end. Our seriouse interest is in the cars. We want to see cars with racing 
      history converted into realistic copys on the VRGTA tracks. The enjoyment for us is in driving and 
      experiencing the cars as they were. Numerous improvements in performance is possible but that is not our 
      desire and our rules are written with the intent to prevent any modifications of the cars used. We want the 
      cars to be what they were not what they could be. Exeptions has been taken for such modifications necessary 
      to make the cars equal enough to race against each other. Original performances is kept to the highest 
      extent possible. More information can be found at vrgt.com



-----------------------------
VRgt Development Team Members
-----------------------------

Name:       Tony "xtonyx"
Title:      Founder of the VRGTA
Location:   The Netherlands
E-mail:     tony@vrgt.com
Task:       Car & Track Conversion/Editing/Creation, ASP/Flash Programming/Design


Name:       Matthias "Matt" Nyberg  -  Sweden  
Title:      Co-Founder of the VRGTA  
Location:   Sweden
E-mail:     matt@vrgt.com
Task:       Perfomance & Sound Editing, Administration		


Name:       Brett "i814t" Walsh
Title:      Development Team Member
Location:   Australia
E-mail:     brett@vrgt.com
Task:       Track & Car Conversion/Editing, LOD optimization, Test-driving


Name:       Graeme "Crash" Johnstone
Title:      Test-driver
Location:   Australia
E-mail:     crash@vrgt.com
Task:       Beta-testing


Name:       Ludwig "Bloodyludy"
Title:      Development Team Member
Location:   Germany
E-mail:     sausages@t-online.de
Task:       Problem Solving, Inventing, Dash Editing, 3D Modeling, Texturing


Name:       Frank "FPwolf" Wolf
Title:      Programmer
Location:   Germany
E-mail:     fpwolf@aol.com
Task:       Programming (doh)
		

Name:       Anders Christian "skorpiworm" Jensen
Title:      Development Team Member
Location:   Denmark
E-mail:     acj@acj-design.dk 
Task:       3D Modeling, Texturing


Name:       "Ashes48" 	
Title:      Development Team Member
Location:   United States
E-mail:     ashes48@comcast.net
Task:       3d Modeling, Track Editing & Converting	

 									
Special thanks goes to both Dave's from MGI(c) !!



-----------------------
Copyright / Permissions
-----------------------

All Cars/Files provided by the VRGTA are copyright by their authors (see Credits). You do not have permission
to put it on any CD-ROM or other media that is to be retailed without the authors prior written conscent. Nor 
can these cars/tracks be used to be demonstrated to the public, without the authors prior written conscent.

Altering/Converting the files provided by the VRGTA is forbidden!



--------------------------------------
Special Note to Webmasters/Site Owners
--------------------------------------

Due to the fact that we are the ones that have put numerous hours in developing these cars, and that they are 
subject to change, they can only be published on the VRgt site. This means no other webmasters are authorized 
to put them on their own server, but you are welcome to link to our main site: http://www.vrgt.com



--------------------
Basic Specifications
--------------------

Base Machine ____________ 1998 Oreca Chrysler Viper GTS-R

Engine __________________ Chrysler 7997 cc V10 
Transmission ____________ 6-speed sequential

Power ___________________ 709 bhp @ 6000 rpm
Torque __________________ 729 lb-ft @ 3900 rpm
Redline _________________ 7200 rpm

Curb Weight _____________ 2535 lbs
Weight Distribution _____ 50% front / 50% rear

Wheels & Tires __________ Goodyear Racing Slicks, 295/35-18 f, 335/35-18 r

Coefficient of Drag _____ 0.35 (with 0 % of maximum downforce)

0-100 kph _______________ 3,5 seconds (with 100% of maximum downforce, no driving aids)
0-160 kph _______________ 6,0 seconds (with 100% of maximum downforce, no driving aids) 
0-200 kph _______________ 8,2 seconds (with 100% of maximum downforce, no driving aids)
200-0 kph _______________ 3,9 seconds (with 100% of maximum downforce, no driving aids)

Topspeed ________________ Atleast 377 kph (with 0% of maximum downforce)
  
Advantages ______________ Acceleration, Topspeed 
Drawbacks _______________ Weight         
                                   

Greetings to the Viper Racing scene !

Have Fun!
