1999 Ford Mustang Cobra
Converted from Need For Speed IV: High Stakes

To best view this readme, click Maximize on Notepad

Origional Author: Ryuji KAINOH
                  ryuji_k@pop13.odn.ne.jp

Converter: Impreza WRX a.k.a. Supra_Twinturbo_R
           Supra_Twinturbo_R@yahoo.com

Installation: Extract mustcob.car and mustcob.jpg to Viper Racing\Data folder
              Rename any .tga file to paint.tga
              Extract paint.tga in the Viper Racing\Config\Paint folder
              Open Viper Racing and select the mustcob.car
              Go to Quick Race, and select paint
              Click Import, then Exit, yes to save

Car Features

* Tinted Windows
* Engine Sounds
* Skinnable Body

Car Upgrades

Class A (High Performance Sports Cars)

Engine

Stock 4.6L V-8

Performance:
             320 HP @ 6500 RPM
             317 ft-lbs. @ 4000 RPM
             Rev Limiter: 7000 RPM

Chassis

Suspension Full-Customization

Drivetrain

Racing Transmission
Racing Differential
Limited Slip Differential

Body

Adjustable Wings

Tires

Standard Performance Tires

Credits:
         3D Mesh- Ryuji KAINOH
         Textures- Ryuji KAINOH
         Sounds- Ryuji KAINOH
         Z-Modeler- Oleg
         Viper Racing- MGI
         Res Tools- FP Wolf

Origional Readme

Ford Mustang Cobra for Need for speed IV

Title          : Ford Mustang Cobra
Car            : Ford Mustang Cobra `99 (SN:27)
File           : cobn.zip
Version        : 1.0 (Upgrade Feature : NO)
Date           : SEP 2000

Author         : Ryuji KAINOH
Email          : ryuji_k@pop13.odn.ne.jp
Homepage       : http://www1.odn.ne.jp/ryuji_k/nfs3.htm

Used Editor(s) : Mrc(cartool.zip) by EA
               : NFS Wizard v0.5.0.79 by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 297) by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 299) by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : NFS Car CAD v1.5b by Chris Barnard
               : CAR3TO4 by J�rg Billeter
               : NFS FCEConverter by Addict&Rocket
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Installation : Put the "car.viv" in "Data\Cars\cobn".
               and  the "cobn.qfs" in "Data\FeArt\VidWall".

Have a fun !!


...Formula1(1987to2000) Carset for ICR2(IndycarRacing2)...
http://www1.odn.ne.jp/ryuji_k