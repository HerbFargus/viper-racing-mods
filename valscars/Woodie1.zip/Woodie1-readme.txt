Woodie1.car  MADE FROM SCRATCH FOR VIPER RACING 9 Feb 2018 BY:

VAL IN MOOSE JAW , SASKATCHEWAN , CANADA.

This car has the same performance as  the Woodie3.car but with normal round wheels.

e-mail          val5662@yahoo.com


PERMISSION INFO:
 If you want to convert this car to any other game go ahead...
.......BUT if you want to modify this car and keep it in Viper 
Racing , go ahead but please rename the car files so we dont have 2 cars with the same name.
Also if you want to use parts from this car , go ahead.
After all , it's only a game.
Thanks!
Cya on the track.
                 Have a great day! 
 