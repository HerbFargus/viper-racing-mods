
A very special Corvette (Z06 Lingenfelter 427 [RED]) with 730 hp and some extras that i�ve converted from the game Need for speed HP2...
I hope you like it...

*Made with:
=>Zmodeler
=>Paint shop pro 7
=>HHD Hex Editor
=>F.P.Wolf VR tools

*Installing*
...Just drop the lfcor.car into your Data folder...and the lfcor.jpg if you use the carman.

=============================================================================================================================
=============================================================================================================================

Wheels (NOT MADE BY ME), are converted from the Need for speed Underground...

=============================================================================================================================
=============================================================================================================================

The exhausts (NOT MADE BY ME) readme:

"this is the Magnex twin square exhausts

3D exhaust
296 poly's

zip contents:
twin square.fce
magnex.tga

author:
Peter Jones
viper_gts
nfsunlimited staff

you have permission to use this part. all i ask is that
you please give full credits if you use the 
part on any car you upload to the internet.

thanks for downloading my part(s)"

=============================================================================================================================
=============================================================================================================================

The spoiler (NOT MADE BY ME) readme:

"this is the BOMZ racing type-z black spoiler

3D spoiler
452 poly's

zip contents:
BOMZ racing type-z black.fce
BOMZ racing type-z black.tga

author:
Peter Jones
viper_gts
nfsunlimited staff

you have permission to use this part. all i ask is that
you please give full credits if you use the 
part on any car you upload to the internet.

thanks for downloading my part(s)"

=============================================================================================================================
=============================================================================================================================

MY mail:

lambogtr777@clix.pt

2004, lambogtr777