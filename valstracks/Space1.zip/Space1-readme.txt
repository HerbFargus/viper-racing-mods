Space1 track  Made for VIPER RACING from scratch 3 August 2014 BY:

VAL IN MOOSE JAW , SASKATCHEWAN , CANADA.

e-mail.......val5662@yahoo.com

If you want any objects seen in this track just email me and I will
send you a link for the track source files.

Track made with Sucahyos vrTrackmaker and other programs.

For all the help / information / tools to get me to this stage of making tracks
for Viper Racing I give Thanks to:
Frank Wolf
Charles
Sucahyo
Tony and Matt from vrgt.com
All others who also helped me since 2003

PERMISSION INFO:
 If you want to convert this track to any other game go ahead...
.......If you want to retexture this track , go ahead but please
credit me as the original track maker and give your name in the 
readme as the retexture author.
After all , it's only a game.
Thanks!
Cya on the track.
                 Have a great day! 