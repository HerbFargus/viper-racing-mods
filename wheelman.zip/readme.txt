WheelMan - the wheel management program for Viper Racing   Version 1.0

This program was designed, because Viper Racing (VR) can, as it was sold, can only use one kind of wheels for all cars. This is the wheel that is inside the file race.res in your Data folder inside your Viper Racing directory. What you need to change this, is the following:
1. This program Wheelman (hurrah, if you read this, you got it already, lol).
2. The new version of race.res, which our Viper guru Ashes48 designed for us. You can get it here: http://www.geocities.com/ashes48/index.html
3. Some wheels in tex format, and the according pictures of them in jpg format, so they show in WheelMan. You can download a pack of wheels from my page (see below) or from a lot of other pages, see the links on my page.

What the programs does: 
it copies the selected wheel, say bbs_ir.tex, to a file called wheeltra.tex in the same directory. This wheeltra.tex is used by the new race.res for all cars. Only those cars that have own wheels inside the car file (included by the wonderful Wheelpackage developed by Xtonyx and Nitroracer) will use their own wheels, and not accept the changes from WheelMan.

For a short overview of how to use look at the picture wmhelp.jpg, that came with this program.

How to install:

1) Move all your wheels (tex and jpg) to the Data folder inside the Viper game, normally C:\Sierra\Viper Racing\Data.

2) If you keep any wheels in a different folder or a subfolder, then move them to the Data folder, otherwise the program won't find them.

3) Move the file wheelman.exe in the same Data folder (important!).

4) Now start wheelman.exe by doubleclicking, and you see 2 boxes. The left one shows all the texes in your Data folder. There may be tex files that are no wheels. Don't use them for wheels, or the game may crash. You can easily tell by the picture, what is what. The right box shows a picture of the selected wheel, if you have a picture in jpg format in the same folder. 

5) Now click the button Apply, this makes the selected wheel the one thast the cars in Viper Racing will use, until you change again. Congratulations, you have successfully changed wheels.

6) To manage your cars in quite the same easy way, install CarMan. It has a button to easily start Wheelman.

Troubleshooting:
Q: I click one of the buttons, and nothing happens, the wheel is not used in VR.
A: - Your wheel is possibly write-protected, and so can't be changed. Please use your Explorer to check which files in your Data folder are write-protected, and remove the protection (see Windows help if necessary).
   - You have used a car that has own wheels, included by the carmaker, and so won't use other wheels.
   - You have the wrong (old) race.res in your Data folder. Get the newone from Ashes48's page (see above).  
Q: The left box is empty.
A: You have started the program from a location, where no wheels are stored. To work properly, the wheelman.exe has to be in the Data folder of Viper, or it won't find nothing.
Q: I can select and change wheels, but no picture shows up on the right side for a certain wheel.
A: You have a wheel, that has no according picture with it. Put a picture of the wheel in jpg format in the same folder, with exactly the same name as the tex file of the wheel. Most every graphics program can convert any picture into jpg format. Make it about the same size as the picture box, 256 x 256.
Q: The wheel in the game is of very simple shape and the colour is plain red.
A: You have not yet selected any wheel using WheelMan, so start it and select one wheel, and it will show in the game.

This game is freeware, use it at your own risk, there is no liability implied to any damages to your cars or Viper game or other things whatsoever.

Developed by Frank P. Wolf for the worldwide Viper community to promote use and racing of as many different wheels as you might wish.

For any questions or comments, good or bad, send me a mail FPWolf@aol.com, or visit my homepage http://members.aol.com/racingwolf999
You can also download CarMan there, as well as lots of rims and pictures to use with CarMan for all existing cars.

Happy Racing all, come to chat in Yahoo Viper Racing Club and let's burn some ruber! 